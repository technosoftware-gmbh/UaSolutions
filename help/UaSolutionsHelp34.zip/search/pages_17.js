var searchData=
[
  ['packages_0',['packages',['../md_Distribution.html#autotoc_md97',1,'NuGet packages'],['../md_ClientDevelopment.html#autotoc_md116',1,'Required NuGet packages'],['../md_ServerDevelopment.html#autotoc_md169',1,'Required NuGet packages']]],
  ['platforms_1',['Supported Platforms',['../md_SupportedPlatforms.html',1,'']]],
  ['preamble_2',['Preamble',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2LICENSE.html#autotoc_md263',1,'']]],
  ['prerequisites_3',['Prerequisites',['../md_Installation.html#autotoc_md81',1,'Prerequisites'],['../md_ClientDevelopment.html#autotoc_md119',1,'Prerequisites'],['../md_ServerDevelopment.html#autotoc_md172',1,'Prerequisites']]],
  ['private_20keys_4',['Certificates and Private keys',['../md_Security.html#autotoc_md39',1,'']]],
  ['product_20lifecycle_5',['Product Lifecycle',['../md_ProductLifeCycle.html',1,'']]],
  ['profiles_6',['Profiles',['../md_Basics.html#autotoc_md21',1,'Profiles'],['../md_ClientDevelopment.html#autotoc_md102',1,'Supported OPC UA Profiles'],['../md_ServerDevelopment.html#autotoc_md155',1,'Supported OPC UA Profiles']]],
  ['program_20cs_7',['Program.cs',['../md_ClientDevelopment.html#autotoc_md152',1,'']]],
  ['program_20customization_8',['Program Customization',['../md_ServerDevelopment.html#autotoc_md187',1,'']]],
  ['programs_9',['Programs',['../md_Basics.html#autotoc_md24',1,'']]],
  ['project_10',['SampleServer project',['../md_ServerDevelopment.html#autotoc_md191',1,'']]],
  ['project_20and_20building_20options_11',['Changes to project and building options',['../md_ServerDevelopment.html#autotoc_md183',1,'']]],
  ['project_20csproj_20file_12',['project csproj file',['../md_Upgrade.html#autotoc_md89',1,'Changes in the project (csproj) file'],['../md_Upgrade.html#autotoc_md93',1,'Changes in the project (csproj) file']]],
  ['pubsub_13',['PubSub',['../md_Basics.html#autotoc_md28',1,'']]]
];
