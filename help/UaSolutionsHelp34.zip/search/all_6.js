var searchData=
[
  ['7_202_0',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]]
];
