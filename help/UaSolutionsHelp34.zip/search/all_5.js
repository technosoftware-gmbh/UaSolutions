var searchData=
[
  ['5_0',['5',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md249',1,'OPC UA Solutions .NET - 3.0.5'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md232',1,'OPC UA Solutions .NET - 3.1.5']]]
];
