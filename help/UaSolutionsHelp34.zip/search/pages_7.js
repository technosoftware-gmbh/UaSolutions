var searchData=
[
  ['8_0',['OPC UA Solutions .NET - 3.1.8',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md229',1,'']]],
  ['8_200_20net_204_208_20or_20net_204_207_202_1',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]],
  ['8_20or_20net_204_207_202_2',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]]
];
