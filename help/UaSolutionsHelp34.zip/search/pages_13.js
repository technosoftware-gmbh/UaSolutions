var searchData=
[
  ['license_20agreement_0',['SOFTWARE LICENSE AGREEMENT',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2LICENSE.html',1,'']]],
  ['license_20state_1',['Checking the license state',['../md_Licensing.html#autotoc_md73',1,'']]],
  ['license_20validation_2',['License Validation',['../md_ClientDevelopment.html#autotoc_md129',1,'']]],
  ['licensing_3',['Licensing',['../md_Licensing.html',1,'']]],
  ['licensing_20the_20solution_4',['Licensing the Solution',['../md_Licensing.html#autotoc_md69',1,'']]],
  ['life_20eol_5',['End of Life (EOL)',['../md_ProductLifeCycle.html#autotoc_md67',1,'']]],
  ['lifecycle_6',['Product Lifecycle',['../md_ProductLifeCycle.html',1,'']]],
  ['linux_7',['Linux',['../md_SupportedPlatforms.html#autotoc_md61',1,'']]],
  ['linux_20ios_20etc_8',['.NET Core applications on Windows, Linux, iOS etc.',['../md_Security.html#autotoc_md44',1,'']]],
  ['local_20discovery_20server_9',['OPC UA Local Discovery Server',['../md_Installation.html#autotoc_md79',1,'']]],
  ['long_20term_20support_20lts_10',['Long Term Support (LTS)',['../md_ProductLifeCycle.html#autotoc_md66',1,'']]],
  ['lts_11',['Long Term Support (LTS)',['../md_ProductLifeCycle.html#autotoc_md66',1,'']]]
];
