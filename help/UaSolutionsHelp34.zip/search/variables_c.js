var searchData=
[
  ['namespaceuris_0',['NamespaceUris',['../classOpc_1_1Ua_1_1SessionLessServiceMessage.html#a67617e9e1b2a7815fce5860562d925bb',1,'Opc::Ua::SessionLessServiceMessage']]],
  ['node_1',['Node',['../classOpc_1_1Ua_1_1NodeState_1_1Notifier.html#af99e562144638798963bf28a2deda385',1,'Opc::Ua::NodeState::Notifier']]],
  ['null_2',['Null',['../structOpc_1_1Ua_1_1Variant.html#acb9039078b76ba5d315f4267caed2d10',1,'Opc::Ua::Variant']]]
];
