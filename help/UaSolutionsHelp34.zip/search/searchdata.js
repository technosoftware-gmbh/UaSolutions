var indexSectionsWithContent =
{
  0: "012345789abcdefghijklmnopqrstuvwxyz“",
  1: "abcdefghijklmnopqrstuvwxy",
  2: "ost",
  3: "abcdefghijklmnopqrstuvwxy",
  4: "abcdefghiklmnopqrstuvw",
  5: "abcdefghijlmnoprstuv",
  6: "abcdefghijklmnopqrstuvwx",
  7: "abcdefghijklmnopqrstuvwxyz",
  8: "bcdeimoprstvw",
  9: "012345789abcdefghiklmnoprstuvwxy“"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events",
  9: "Pages"
};

