var searchData=
[
  ['historyupdatetype_0',['HistoryUpdateType',['../namespaceOpc_1_1Ua.html#ad056b0560b409fb0aefc05bb8311f72e',1,'Opc::Ua']]]
];
