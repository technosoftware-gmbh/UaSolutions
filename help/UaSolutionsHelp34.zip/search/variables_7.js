var searchData=
[
  ['historyreadrequest_0',['HistoryReadRequest',['../classOpc_1_1Ua_1_1HistoryReadMessage.html#a0500fd24034d13259f1e4dca673f25c8',1,'Opc::Ua::HistoryReadMessage']]],
  ['historyreadresponse_1',['HistoryReadResponse',['../classOpc_1_1Ua_1_1HistoryReadResponseMessage.html#a8c9cddd6976621134cf939b8ab62bdc8',1,'Opc::Ua::HistoryReadResponseMessage']]],
  ['historyupdaterequest_2',['HistoryUpdateRequest',['../classOpc_1_1Ua_1_1HistoryUpdateMessage.html#a0efdaf1b46411648190371a03294f98e',1,'Opc::Ua::HistoryUpdateMessage']]],
  ['historyupdateresponse_3',['HistoryUpdateResponse',['../classOpc_1_1Ua_1_1HistoryUpdateResponseMessage.html#ae604d892b6f939852641d6be676473c3',1,'Opc::Ua::HistoryUpdateResponseMessage']]]
];
