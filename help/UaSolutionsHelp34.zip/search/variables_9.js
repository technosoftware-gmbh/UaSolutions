var searchData=
[
  ['kdefaultconfigmajorversion_0',['kDefaultConfigMajorVersion',['../classTechnosoftware_1_1UaPubSub_1_1UaDataSetMessage.html#a596c52aa6f841906c4d1c5800a28816f',1,'Technosoftware::UaPubSub::UaDataSetMessage']]],
  ['kdefaultconfigminorversion_1',['kDefaultConfigMinorVersion',['../classTechnosoftware_1_1UaPubSub_1_1UaDataSetMessage.html#ad2ed1cf663d0385d4721848bbdf82e4c',1,'Technosoftware::UaPubSub::UaDataSetMessage']]]
];
