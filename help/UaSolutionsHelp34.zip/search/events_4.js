var searchData=
[
  ['impersonateuserevent_0',['ImpersonateUserEvent',['../interfaceTechnosoftware_1_1UaServer_1_1IUaSessionManager.html#a9aa23fbf90af1ecfedcaafc204515cbd',1,'Technosoftware.UaServer.IUaSessionManager.ImpersonateUserEvent'],['../classTechnosoftware_1_1UaServer_1_1Sessions_1_1SessionManager.html#ae02d80803816e7f774395bee5e91788d',1,'Technosoftware.UaServer.Sessions.SessionManager.ImpersonateUserEvent']]]
];
