var searchData=
[
  ['features_0',['Features',['../md_ClientDevelopment.html#autotoc_md105',1,'Client Security Features'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md200',1,'New Features'],['../md_ServerDevelopment.html#autotoc_md158',1,'Server Security Features']]],
  ['features_20included_1',['Features Included',['../md_Distribution.html#autotoc_md99',1,'']]],
  ['file_2',['file',['../md_Upgrade.html#autotoc_md90',1,'Changes in the configuration file'],['../md_Upgrade.html#autotoc_md94',1,'Changes in the configuration file'],['../md_Upgrade.html#autotoc_md89',1,'Changes in the project (csproj) file'],['../md_Upgrade.html#autotoc_md93',1,'Changes in the project (csproj) file']]],
  ['files_3',['Renaming files',['../md_ServerDevelopment.html#autotoc_md182',1,'']]],
  ['fix_4',['Security Fix',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md211',1,'']]],
  ['fixed_20issues_5',['Fixed issues',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md217',1,'Fixed issues'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md221',1,'Fixed issues'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md227',1,'Fixed issues'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md234',1,'Fixed issues'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md247',1,'Fixed issues']]],
  ['fixes_6',['Fixes',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md202',1,'']]],
  ['for_20testing_7',['Environments used for testing',['../md_Installation.html#autotoc_md76',1,'']]],
  ['framworks_8',['Supported .NET framworks',['../md_SupportedPlatforms.html#autotoc_md63',1,'']]],
  ['from_203_203_20to_203_204_9',['Upgrade from 3.3 to 3.4',['../md_Upgrade.html',1,'']]]
];
