var searchData=
[
  ['9_0',['OPC UA Solutions .NET - 3.1.9',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md226',1,'']]],
  ['9_200_1',['Test your installation with .NET 9.0',['../md_Installation.html#autotoc_md80',1,'']]],
  ['9_200_20net_208_200_20net_204_208_20or_20net_204_207_202_2',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]]
];
