var searchData=
[
  ['ontokenactivated_0',['OnTokenActivated',['../classOpc_1_1Ua_1_1UaChannelBase.html#ab32508ae1314747477ab739217740916',1,'Opc.Ua.UaChannelBase.OnTokenActivated'],['../classOpc_1_1Ua_1_1Bindings_1_1UaSCUaBinaryTransportChannel.html#a51021f717f615292600978a06112f654',1,'Opc.Ua.Bindings.UaSCUaBinaryTransportChannel.OnTokenActivated'],['../interfaceOpc_1_1Ua_1_1ITransportChannel.html#ac071db777e141c592b4c5dae84d661f8',1,'Opc.Ua.ITransportChannel.OnTokenActivated']]]
];
