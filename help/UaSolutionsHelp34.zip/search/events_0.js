var searchData=
[
  ['browserevent_0',['BrowserEvent',['../classTechnosoftware_1_1UaClient_1_1Browser.html#aaa3ae0153e6325b58ec10d04a9e26566',1,'Technosoftware::UaClient::Browser']]]
];
