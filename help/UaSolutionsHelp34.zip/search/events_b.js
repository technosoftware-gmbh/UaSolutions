var searchData=
[
  ['validatesessionlessrequestevent_0',['ValidateSessionLessRequestEvent',['../interfaceTechnosoftware_1_1UaServer_1_1IUaSessionManager.html#acc81903ccb7a18624e25c7f55c172e40',1,'Technosoftware.UaServer.IUaSessionManager.ValidateSessionLessRequestEvent'],['../classTechnosoftware_1_1UaServer_1_1Sessions_1_1SessionManager.html#a1a8b36426149b11da9bb495f83884914',1,'Technosoftware.UaServer.Sessions.SessionManager.ValidateSessionLessRequestEvent']]]
];
