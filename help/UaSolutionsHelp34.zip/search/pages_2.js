var searchData=
[
  ['2_0',['2',['../md_Distribution.html#autotoc_md98',1,'.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md258',1,'OPC UA Solutions .NET - 3.0.2'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md223',1,'OPC UA Solutions .NET - 3.2.2'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md206',1,'OPC UA Solutions .NET - 3.3.2']]],
  ['2_202_1',['OPC UA Solutions .NET - 3.2.2',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md223',1,'']]],
  ['2_203_2',['OPC UA Solutions .NET - 3.2.3',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md219',1,'']]],
  ['2_20server_20authentication_3',['Tier 2 - Server Authentication',['../md_Security.html#autotoc_md34',1,'']]]
];
