var searchData=
[
  ['0_0',['0',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md245',1,'OPC UA Solutions .NET - 3.1.0'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md214',1,'OPC UA Solutions .NET - 3.3.0'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md197',1,'OPC UA Solutions .NET - 3.4.0'],['../md_Installation.html#autotoc_md80',1,'Test your installation with .NET 9.0']]],
  ['0_202_1',['OPC UA Solutions .NET - 3.0.2',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md258',1,'']]],
  ['0_203_2',['OPC UA Solutions .NET - 3.0.3',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md255',1,'']]],
  ['0_204_3',['OPC UA Solutions .NET - 3.0.4',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md252',1,'']]],
  ['0_205_4',['OPC UA Solutions .NET - 3.0.5',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md249',1,'']]],
  ['0_20net_204_208_20or_20net_204_207_202_5',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]],
  ['0_20net_208_200_20net_204_208_20or_20net_204_207_202_6',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]],
  ['0_20wcf_7',['OPC .NET 4.0 (WCF)',['../index.html#autotoc_md7',1,'']]]
];
