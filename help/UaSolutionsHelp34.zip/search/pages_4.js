var searchData=
[
  ['4_0',['4',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md252',1,'OPC UA Solutions .NET - 3.0.4'],['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md236',1,'OPC UA Solutions .NET - 3.1.4'],['../md_Upgrade.html',1,'Upgrade from 3.3 to 3.4']]],
  ['4_200_1',['OPC UA Solutions .NET - 3.4.0',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md197',1,'']]],
  ['4_200_20wcf_2',['OPC .NET 4.0 (WCF)',['../index.html#autotoc_md7',1,'']]],
  ['4_201_3',['OPC UA Solutions .NET - 3.4.1',['../md_c_1_2opcua-solution-net-fork-34_2dotnetcore_2CHANGELOG.html#autotoc_md194',1,'']]],
  ['4_207_202_4',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]],
  ['4_208_20or_20net_204_207_202_5',['.NET 9.0, .NET 8.0, .NET 4.8 or .NET 4.7.2',['../md_Distribution.html#autotoc_md98',1,'']]],
  ['4_20mutual_20authentication_6',['Tier 4 - Mutual Authentication',['../md_Security.html#autotoc_md36',1,'']]]
];
