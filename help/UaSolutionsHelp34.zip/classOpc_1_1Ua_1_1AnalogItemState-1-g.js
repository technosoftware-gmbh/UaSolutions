var classOpc_1_1Ua_1_1AnalogItemState_1_g =
[
    [ "AnalogItemState", "classOpc_1_1Ua_1_1AnalogItemState-1-g.html#a15824f161eda0d67b838b84e7ee325b5", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AnalogItemState-1-g.html#a8f1cd6652e095c17ba76cf0fa83285e6", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AnalogItemState-1-g.html#a57b9d68ff2d5739026127f8b8e14e9b6", null ],
    [ "Value", "classOpc_1_1Ua_1_1AnalogItemState-1-g.html#a258f312890a74b7eeb1516a4d3240230", null ]
];