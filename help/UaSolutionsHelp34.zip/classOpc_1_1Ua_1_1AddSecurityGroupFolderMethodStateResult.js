var classOpc_1_1Ua_1_1AddSecurityGroupFolderMethodStateResult =
[
    [ "SecurityGroupFolderNodeId", "classOpc_1_1Ua_1_1AddSecurityGroupFolderMethodStateResult.html#a98837bae3361174f23b58c56455e2601", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddSecurityGroupFolderMethodStateResult.html#a0218bfb415c45a836b385b26712744b8", null ]
];