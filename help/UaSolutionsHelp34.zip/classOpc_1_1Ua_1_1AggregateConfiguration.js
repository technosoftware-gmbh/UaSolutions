var classOpc_1_1Ua_1_1AggregateConfiguration =
[
    [ "AggregateConfiguration", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a6f3925d4ec2fbcf9b7ac5e819eae68c8", null ],
    [ "Clone", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a1c9940f0751f287d920aa09b540f9541", null ],
    [ "Decode", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a6f8310e44d7ea7df8e9f88d9e4fa3c0f", null ],
    [ "Encode", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a7f7b623d93f9dbce0f04e518a52da427", null ],
    [ "IsEqual", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a030e15e7d0c35629d65e08ca357bf016", null ],
    [ "MemberwiseClone", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a6b06fd7004bcde0e65287c706c43a5a5", null ],
    [ "BinaryEncodingId", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a69c58a3908ec614812374013823124c7", null ],
    [ "JsonEncodingId", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a3512a75d880b760025db92e829ef4d6c", null ],
    [ "PercentDataBad", "classOpc_1_1Ua_1_1AggregateConfiguration.html#ac1ef4755f60becf389abee7273e9d2ba", null ],
    [ "PercentDataGood", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a891fe9d7559599cefb3c8a3b1dc2c658", null ],
    [ "TreatUncertainAsBad", "classOpc_1_1Ua_1_1AggregateConfiguration.html#ade97f25cadae14e5ba4a934c60d2bc11", null ],
    [ "TypeId", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a82bc8629399c9a6c612a08f1e27dbd85", null ],
    [ "UseServerCapabilitiesDefaults", "classOpc_1_1Ua_1_1AggregateConfiguration.html#ac1d144cb83466fdc922e0c4983cbd227", null ],
    [ "UseSlopedExtrapolation", "classOpc_1_1Ua_1_1AggregateConfiguration.html#ab3a8f04dba6668cc914dd4aad55f4d9d", null ],
    [ "XmlEncodingId", "classOpc_1_1Ua_1_1AggregateConfiguration.html#a3b3114f53989ede6727f501e7aefb6fb", null ]
];