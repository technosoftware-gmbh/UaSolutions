var classOpc_1_1Ua_1_1AddDataSetFolderMethodStateResult =
[
    [ "DataSetFolderNodeId", "classOpc_1_1Ua_1_1AddDataSetFolderMethodStateResult.html#afc6f567301e636560b4193497f27f5ce", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddDataSetFolderMethodStateResult.html#ab052934c6b9f86acdfcc0f7673e2e491", null ]
];