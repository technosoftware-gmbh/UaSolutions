var classOpc_1_1Ua_1_1AggregateFunctionState =
[
    [ "AggregateFunctionState", "classOpc_1_1Ua_1_1AggregateFunctionState.html#ac9da8cb9891bb59f3e698a5d40b652c0", null ],
    [ "GetDefaultTypeDefinitionId", "classOpc_1_1Ua_1_1AggregateFunctionState.html#a3e068dc0dd2d60fc44e7aa21aa674162", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AggregateFunctionState.html#a5beb40c9014aec0896dd91fae321282c", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AggregateFunctionState.html#a36b35c6cddb9f855921def0df6bf2890", null ],
    [ "InitializeOptionalChildren", "classOpc_1_1Ua_1_1AggregateFunctionState.html#aa4857235d583f10e6234262dd6b28344", null ]
];