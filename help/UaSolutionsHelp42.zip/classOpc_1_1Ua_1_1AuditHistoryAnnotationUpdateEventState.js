var classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState =
[
    [ "AuditHistoryAnnotationUpdateEventState", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#a414a52deae3a8318804a954bdbbff75b", null ],
    [ "FindChild", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#a732690ed6d35af4fdf81fa3f9e040968", null ],
    [ "GetChildren", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#abe951521d20a9caf3a9f4b6a4c50a525", null ],
    [ "GetDefaultTypeDefinitionId", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#a07e22032e6bd43dc5e5781f4792d816e", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#a560abf98dfca1f526104f3e878c53699", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#ac0c8c8f57be0fa8bbf41c00b9c3e02dc", null ],
    [ "InitializeOptionalChildren", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#a634a738a8ac674e25e1302383c92cdb7", null ],
    [ "NewValues", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#a11bb78cc6b6f9dfc693544e23fee7010", null ],
    [ "OldValues", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#a3f4522eeb11182279d99eeb4960be8ab", null ],
    [ "PerformInsertReplace", "classOpc_1_1Ua_1_1AuditHistoryAnnotationUpdateEventState.html#abcac88fe54299f3ef8ca47e79ff7b363", null ]
];