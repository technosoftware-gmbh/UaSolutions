var classOpc_1_1Ua_1_1AddConnectionMethodStateResult =
[
    [ "ConnectionId", "classOpc_1_1Ua_1_1AddConnectionMethodStateResult.html#a3a6ad1c1bfd7efa2033572cfdf624882", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddConnectionMethodStateResult.html#a212d81cfc4538726d58e72f0cbeca509", null ]
];