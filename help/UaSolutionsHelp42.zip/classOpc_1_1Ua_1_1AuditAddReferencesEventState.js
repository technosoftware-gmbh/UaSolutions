var classOpc_1_1Ua_1_1AuditAddReferencesEventState =
[
    [ "AuditAddReferencesEventState", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#a2cc11482cd91ebc6588ef67c36f4578b", null ],
    [ "FindChild", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#a54a0dbea406fa52d2997ca71c2daeebd", null ],
    [ "GetChildren", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#aabca4a6311ec501d9bdaa5030d76e5ff", null ],
    [ "GetDefaultTypeDefinitionId", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#a80d7b3c45f97eacd3eec6af676b6febb", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#aa114cfa00b18373bb0ffc4e65198b6b4", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#a592f937e93e8c30745a3185d65bb2cfc", null ],
    [ "InitializeOptionalChildren", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#a576b4bb6dfe11a6fcbbaf9a13b8c1db9", null ],
    [ "ReferencesToAdd", "classOpc_1_1Ua_1_1AuditAddReferencesEventState.html#a5fa443c7306319bd1b66710e1a471253", null ]
];