var classOpc_1_1Ua_1_1AddPublishedEventsTemplateMethodStateResult =
[
    [ "DataSetNodeId", "classOpc_1_1Ua_1_1AddPublishedEventsTemplateMethodStateResult.html#a5543630808ec9cf71cf752dbe922e156", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddPublishedEventsTemplateMethodStateResult.html#aea119dfb6660d82bdf859c6880dbf07a", null ]
];