var classOpc_1_1Ua_1_1AddPushTargetMethodStateResult =
[
    [ "PushTargetId", "classOpc_1_1Ua_1_1AddPushTargetMethodStateResult.html#a8f93ba935b5a491e417dc5dd474fd105", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddPushTargetMethodStateResult.html#a0f921b4016a838edae53fb5da19f97cb", null ]
];