var classOpc_1_1Ua_1_1AddPushTargetFolderMethodStateResult =
[
    [ "PushTargetFolderNodeId", "classOpc_1_1Ua_1_1AddPushTargetFolderMethodStateResult.html#a695966b02551dc1bce1faf8b086e8a73", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddPushTargetFolderMethodStateResult.html#af1f0cb12de4cea3adc0ce5feb82dedd7", null ]
];