var classOpc_1_1Ua_1_1AddNodesItem =
[
    [ "AddNodesItem", "classOpc_1_1Ua_1_1AddNodesItem.html#ac3e66108a6fe58c5c49791ca341d40a5", null ],
    [ "Clone", "classOpc_1_1Ua_1_1AddNodesItem.html#ae5ceb77a5c611d17c6fb9200ec262fea", null ],
    [ "Decode", "classOpc_1_1Ua_1_1AddNodesItem.html#a1903ecfdfbcf1f37613a41563db1decf", null ],
    [ "Encode", "classOpc_1_1Ua_1_1AddNodesItem.html#afe4a4cc8dbebc96dace24c1505e91a5f", null ],
    [ "IsEqual", "classOpc_1_1Ua_1_1AddNodesItem.html#ae09fedd55ee4d0c1c8b469a3e7c4e179", null ],
    [ "MemberwiseClone", "classOpc_1_1Ua_1_1AddNodesItem.html#ad946bf87f33c0dba7c66b3f2d64ca719", null ],
    [ "BinaryEncodingId", "classOpc_1_1Ua_1_1AddNodesItem.html#a23f61ec7823c0849ab7de7a7befdd8b2", null ],
    [ "BrowseName", "classOpc_1_1Ua_1_1AddNodesItem.html#a121f7d18acf5056398e43ff1e691e20b", null ],
    [ "JsonEncodingId", "classOpc_1_1Ua_1_1AddNodesItem.html#a3caa0a0b696c52634c8fedba0da5ea92", null ],
    [ "NodeAttributes", "classOpc_1_1Ua_1_1AddNodesItem.html#a647554c10b309040450a66e49628cf73", null ],
    [ "NodeClass", "classOpc_1_1Ua_1_1AddNodesItem.html#a079f120fed51c6b13ac775779f77f7ea", null ],
    [ "ParentNodeId", "classOpc_1_1Ua_1_1AddNodesItem.html#aad40b8f738f38ff7b23e320af076d08b", null ],
    [ "ReferenceTypeId", "classOpc_1_1Ua_1_1AddNodesItem.html#ac703724b5f61e7bd571e1907ac5539a1", null ],
    [ "RequestedNewNodeId", "classOpc_1_1Ua_1_1AddNodesItem.html#a31da32f6f9c68f50891e5bc822c8a03e", null ],
    [ "TypeDefinition", "classOpc_1_1Ua_1_1AddNodesItem.html#accb40de5d65224743c20f3b8b62ee3cc", null ],
    [ "TypeId", "classOpc_1_1Ua_1_1AddNodesItem.html#ab715251a57dc2f5b5dc73d93e614a9b7", null ],
    [ "XmlEncodingId", "classOpc_1_1Ua_1_1AddNodesItem.html#ab10c647f0eefea1783aaf307b648c324", null ]
];