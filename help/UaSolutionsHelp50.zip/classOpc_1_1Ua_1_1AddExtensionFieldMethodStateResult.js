var classOpc_1_1Ua_1_1AddExtensionFieldMethodStateResult =
[
    [ "FieldId", "classOpc_1_1Ua_1_1AddExtensionFieldMethodStateResult.html#abe5800261502e823ddc5808cbb475364", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddExtensionFieldMethodStateResult.html#a954108ab2b8bd9631c532c4d2d0523b2", null ]
];