var classOpc_1_1Ua_1_1AddRoleMethodStateResult =
[
    [ "RoleNodeId", "classOpc_1_1Ua_1_1AddRoleMethodStateResult.html#aa7debce778976ec96844e686dfcdcae6", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddRoleMethodStateResult.html#a516360e6c73fb97b8cf6364393c6d747", null ]
];