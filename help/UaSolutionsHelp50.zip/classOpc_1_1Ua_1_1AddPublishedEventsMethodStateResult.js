var classOpc_1_1Ua_1_1AddPublishedEventsMethodStateResult =
[
    [ "ConfigurationVersion", "classOpc_1_1Ua_1_1AddPublishedEventsMethodStateResult.html#afa2f6434b26147b6b3df9d0bbd453c15", null ],
    [ "DataSetNodeId", "classOpc_1_1Ua_1_1AddPublishedEventsMethodStateResult.html#af504b58aa7b46541f1947601b4e0d4d5", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddPublishedEventsMethodStateResult.html#a22de44f06ba7e597c22ce4a77c6c5d42", null ]
];