var classOpc_1_1Ua_1_1AddReferencesRequest =
[
    [ "AddReferencesRequest", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a205abd3caeee9dbec4ef895e932bfaa6", null ],
    [ "Clone", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a9ffda70bfa4ed69521281741c5fd1539", null ],
    [ "Decode", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a27077fb280d7c4dcccedfebb44c4a1a9", null ],
    [ "Encode", "classOpc_1_1Ua_1_1AddReferencesRequest.html#aeefcaa3961b27cab26a8a364efaaaa9e", null ],
    [ "IsEqual", "classOpc_1_1Ua_1_1AddReferencesRequest.html#ab4cdc018c3d1c39a6e49778654b8ccde", null ],
    [ "MemberwiseClone", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a39271581ec33d9efaa75bd8a65b9f98d", null ],
    [ "BinaryEncodingId", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a16f887e4e769a407fec6dd10c676b32f", null ],
    [ "JsonEncodingId", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a09895abcc77b063b23ed820dc595da22", null ],
    [ "ReferencesToAdd", "classOpc_1_1Ua_1_1AddReferencesRequest.html#ad1e0e6c54926137f7d92367d75b4f283", null ],
    [ "RequestHeader", "classOpc_1_1Ua_1_1AddReferencesRequest.html#ae89f939ce551a3153fd28af5b4445d56", null ],
    [ "TypeId", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a776a9d177abba83e7d70c4e263f438af", null ],
    [ "XmlEncodingId", "classOpc_1_1Ua_1_1AddReferencesRequest.html#a5091522dd4ff4ead2e713716b572a835", null ]
];