var classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState =
[
    [ "AuditHistoryValueUpdateEventState", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#aa5a37dd52c71ce41f3ec8dd6ee597404", null ],
    [ "FindChild", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#ad37a4e93cd216dc1aef18ae35ca07c67", null ],
    [ "GetChildren", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a5592d5001224067219ace245c150b874", null ],
    [ "GetDefaultTypeDefinitionId", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a4a7a25046ddd75ed586d698f78e2ea6d", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a087d84ece2fcec3cc3d7e2307935444a", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#acdea32d47b28c237a12d622892a8c9e7", null ],
    [ "InitializeOptionalChildren", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a534072c3d2c71300f3c1297f2160c38b", null ],
    [ "RemoveExplicitlyDefinedChild", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a09d8a258b1e92a8b58b5bdda2284f167", null ],
    [ "NewValues", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#ad3d20c63c2f32e490c898c35b2cb6e0d", null ],
    [ "OldValues", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a7335b2510e7138c10797b22401317c63", null ],
    [ "PerformInsertReplace", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a9fb6a17258f24b63e2efcc64d7586361", null ],
    [ "UpdatedNode", "classOpc_1_1Ua_1_1AuditHistoryValueUpdateEventState.html#a676a4f90b3097f1e0bd9fc8abebc725a", null ]
];