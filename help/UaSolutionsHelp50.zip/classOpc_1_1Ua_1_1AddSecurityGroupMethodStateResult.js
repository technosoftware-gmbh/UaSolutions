var classOpc_1_1Ua_1_1AddSecurityGroupMethodStateResult =
[
    [ "SecurityGroupId", "classOpc_1_1Ua_1_1AddSecurityGroupMethodStateResult.html#a56cad96a9a45fd451422efe6b20052b2", null ],
    [ "SecurityGroupNodeId", "classOpc_1_1Ua_1_1AddSecurityGroupMethodStateResult.html#a3070078a97518b12f263be6c525d8557", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddSecurityGroupMethodStateResult.html#abcabb4ffba3f34b01255ccb196efa573", null ]
];