var classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState =
[
    [ "AuditHistoryEventDeleteEventState", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#ac465bfde23cc7f00e8ee054f135bb192", null ],
    [ "FindChild", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#a3f92a79802261eb58dba9ca61e5452a6", null ],
    [ "GetChildren", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#a29a1e6d4be1d5fee5f470f9d3cfa29a3", null ],
    [ "GetDefaultTypeDefinitionId", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#a4f6ad4ab723c7617b379b9ecad453121", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#af1bc2003ab6dc2c422430007e14c8014", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#a5a39ac31d2275e80220ab28bb16c8fe8", null ],
    [ "InitializeOptionalChildren", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#acccf3680aab8ccd9fa0dfb571032d462", null ],
    [ "RemoveExplicitlyDefinedChild", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#a7a2f67bd1c886bd8b06fc29446e66d7b", null ],
    [ "EventIds", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#a70b65105645395d3e69c12f826eb29d0", null ],
    [ "OldValues", "classOpc_1_1Ua_1_1AuditHistoryEventDeleteEventState.html#a5d844cdea6f256ed57ee5112e4fd1349", null ]
];