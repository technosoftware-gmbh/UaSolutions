var classOpc_1_1Ua_1_1AddPublishedDataItemsTemplateMethodStateResult =
[
    [ "AddResults", "classOpc_1_1Ua_1_1AddPublishedDataItemsTemplateMethodStateResult.html#a7a761170c2f19c13480bb05af9106b7a", null ],
    [ "DataSetNodeId", "classOpc_1_1Ua_1_1AddPublishedDataItemsTemplateMethodStateResult.html#a633df6ae17cfd7046c6b9c706b064fba", null ],
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddPublishedDataItemsTemplateMethodStateResult.html#a191d92a5d7cdd18c7fb51aab44599859", null ]
];