var classOpc_1_1Ua_1_1AuditHistoryConfigurationChangeEventState =
[
    [ "AuditHistoryConfigurationChangeEventState", "classOpc_1_1Ua_1_1AuditHistoryConfigurationChangeEventState.html#adacdefd7d3a9d2e29f41e64cf92c1e17", null ],
    [ "GetDefaultTypeDefinitionId", "classOpc_1_1Ua_1_1AuditHistoryConfigurationChangeEventState.html#a4af37dfbdf9cdfa3c75d5de3ff82d625", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryConfigurationChangeEventState.html#a9100ae1d8f169c530bc43b30cf0d5a82", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AuditHistoryConfigurationChangeEventState.html#a5e4a125a9bacc86ad1e43014f6da4d9a", null ],
    [ "InitializeOptionalChildren", "classOpc_1_1Ua_1_1AuditHistoryConfigurationChangeEventState.html#a038794036a3dee4e0d720f3bf4159e34", null ]
];