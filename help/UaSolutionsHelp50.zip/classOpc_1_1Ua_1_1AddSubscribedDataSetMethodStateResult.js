var classOpc_1_1Ua_1_1AddSubscribedDataSetMethodStateResult =
[
    [ "ServiceResult", "classOpc_1_1Ua_1_1AddSubscribedDataSetMethodStateResult.html#a273d31a4f703eadf60572d3e4d5453f7", null ],
    [ "SubscribedDataSetNodeId", "classOpc_1_1Ua_1_1AddSubscribedDataSetMethodStateResult.html#a337ec47e0756d927eef30f0b8df12efb", null ]
];