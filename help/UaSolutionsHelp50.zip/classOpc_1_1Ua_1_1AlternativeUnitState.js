var classOpc_1_1Ua_1_1AlternativeUnitState =
[
    [ "AlternativeUnitState", "classOpc_1_1Ua_1_1AlternativeUnitState.html#a0b3ca4f2b3e11cfc6f2bd97048578d36", null ],
    [ "FindChild", "classOpc_1_1Ua_1_1AlternativeUnitState.html#afc09f5011cde66d2e575ec0ca6798bb5", null ],
    [ "GetChildren", "classOpc_1_1Ua_1_1AlternativeUnitState.html#a007f9300a7bd0128dfff716103302883", null ],
    [ "GetDefaultTypeDefinitionId", "classOpc_1_1Ua_1_1AlternativeUnitState.html#aafc8218ecb5e86db209f51572bef17a2", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AlternativeUnitState.html#ad5c583577db9a7cbff2153e5a85bb41d", null ],
    [ "Initialize", "classOpc_1_1Ua_1_1AlternativeUnitState.html#ac21e29172b9fb44d87b00c6cae232217", null ],
    [ "InitializeOptionalChildren", "classOpc_1_1Ua_1_1AlternativeUnitState.html#a99330ceff554bb9e48a462f5dfdc482b", null ],
    [ "RemoveExplicitlyDefinedChild", "classOpc_1_1Ua_1_1AlternativeUnitState.html#a49189fb4e0f30de0d0182ae6651a3301", null ],
    [ "LinearConversion", "classOpc_1_1Ua_1_1AlternativeUnitState.html#adaadddf68579e21d90f71da7f91f2fb6", null ],
    [ "MathMLConversion", "classOpc_1_1Ua_1_1AlternativeUnitState.html#a4890d602b88686d82b5ef439c1df65e3", null ],
    [ "MathMLInverseConversion", "classOpc_1_1Ua_1_1AlternativeUnitState.html#a38150428d52ac8a4a523f38ded943a30", null ]
];